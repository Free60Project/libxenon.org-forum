#include <stdio.h>
#include <xenos/xenos.h>
#include <console/console.h>
#include <math.h>
#include <SDL/SDL.h>

#define	PI	3.14159265358979323846



void mainInit(){
	xenos_init(VIDEO_MODE_AUTO);
	console_init();

	kmem_init();
	usb_init();
	usb_do_poll();
}


void drawline(SDL_Surface *surface,Sint16 x1,Sint16 y1,Sint16 x2,Sint16 y2,Uint8 r,Uint8 g,Uint8 b)
{
	Uint32 color;
	if ( SDL_MUSTLOCK(surface) ) 
	{
		if ( SDL_LockSurface(surface) < 0 ) 
		{
			fprintf(stderr, "Can't lock screen: %s\n", SDL_GetError());
			SDL_Quit();
		}
	}

	color = SDL_MapRGB(surface->format,r,g,b);
	Sint16 dx, dy, sdx, sdy, x, y;

	dx = x2 - x1;
	dy = y2 - y1;

	sdx = (dx < 0) ? -1 : 1;
	sdy = (dy < 0) ? -1 : 1;

	dx = sdx * dx + 1;
	dy = sdy * dy + 1;

	x = y = 0;

	Sint16 pixx = surface->format->BytesPerPixel;
	Sint16 pixy = surface->pitch;
	Uint8 *pixel = (Uint8*)surface->pixels + y1*pixy + x1*pixx;

	pixx *= sdx;
	pixy *= sdy;

	if (dx < dy)
	{
		Sint32 tmp = dx;
		dx = dy;
		dy = (Sint16)(tmp);
		tmp = pixx;
		pixx = pixy;
		pixy = tmp;
	}



	for (x=0; x < dx; x++)
	{
		*(Uint32*)pixel = color;

		y += dy;
		if (y >= dx)
		{
			y -= dx;
			pixel += pixy;
		}
		pixel += pixx;
	}

	if ( SDL_MUSTLOCK(surface) )
	{
		SDL_UnlockSurface(surface);
	}

}

int main(int argc, char* argv[])
{
	mainInit();
	SDL_Surface *screen;
	int k,xint=320,yint=240,xold,yold;
	float a=0.25,b=0.25;
	float x,y,theta=0;

	if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_JOYSTICK) < 0 ) 
	{
		fprintf(stderr, "Couldn't initialize SDL: %s\n", SDL_GetError());	
		SDL_Quit();
	}
   
	screen = SDL_SetVideoMode(640,480,32,SDL_FULLSCREEN|SDL_HWSURFACE);



	for(k=0;k<110;k++)
	{
		xold=xint;
		yold=yint;
		x=a*cos(theta)*exp(b*theta);
		y=a*sin(theta)*exp(b*theta);
		xint=(int)x+320;
		yint=(int)y+240;
		SDL_Delay(100);
		drawline(screen,xold,yold,xint,yint,0x00,0xd0,0xff);
		SDL_UpdateRect(screen,0,0,0,0);		
		theta=k*(PI/12);

	}


	SDL_Delay(60000);


  
	return 0;
}






