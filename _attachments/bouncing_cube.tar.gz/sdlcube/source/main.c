#include <stdio.h>
#include <xenos/xenos.h>
#include <console/console.h>
#include <math.h>
#include <SDL/SDL.h>

#define	PI	3.14159265358979323846

		    //Ax  Ay  Bx  By  Cx  Cy  Dx  Dy  Ex  Ey  Fx  Fy  Gx  Gy  Hx  Hy
float cubepoints[16]={300,220,340,220,300,260,340,260,280,200,320,200,280,240,320,240};
float rotatedpoints[16];

void mainInit(){
	xenos_init(VIDEO_MODE_AUTO);
	console_init();

	kmem_init();
	usb_init();
	usb_do_poll();
}


void drawline(SDL_Surface *surface, int x1, int y1, int x2, int y2, Uint8 r, Uint8 g, Uint8 b)
{
	if ( SDL_MUSTLOCK(surface) ) 
	{
		if ( SDL_LockSurface(surface) < 0 ) 
		{
			fprintf(stderr, "Can't lock screen: %s\n", SDL_GetError());
			SDL_Quit();
		}
	}

	Uint32 color=SDL_MapRGB(surface->format, r, g, b );
	Sint16 dx, dy, sdx, sdy, x, y;

	dx = x2 - x1;
	dy = y2 - y1;

	sdx = (dx < 0) ? -1 : 1;
	sdy = (dy < 0) ? -1 : 1;

	dx = sdx * dx + 1;
	dy = sdy * dy + 1;

	x = y = 0;

	Sint16 pixx = surface->format->BytesPerPixel;
	Sint16 pixy = surface->pitch;
	Uint8 *pixel = (Uint8*)surface->pixels + y1*pixy + x1*pixx;

	pixx *= sdx;
	pixy *= sdy;

	if (dx < dy)
	{
		Sint32 tmp = dx;
		dx = dy;
		dy = (Sint16)(tmp);
		tmp = pixx;
		pixx = pixy;
		pixy = tmp;
	}



	for (x=0; x < dx; x++)
	{
		*(Uint32*)pixel = color;

		y += dy;
		if (y >= dx)
		{
			y -= dx;
			pixel += pixy;
		}
		pixel += pixx;
	}

	if ( SDL_MUSTLOCK(surface) )
	{
		SDL_UnlockSurface(surface);
	}

}

void drawcube(SDL_Surface *surface)
{
	drawline(surface,(int)rotatedpoints[0],(int)rotatedpoints[1],(int)rotatedpoints[8],(int)rotatedpoints[9],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[0],(int)rotatedpoints[1],(int)rotatedpoints[2],(int)rotatedpoints[3],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[0],(int)rotatedpoints[1],(int)rotatedpoints[4],(int)rotatedpoints[5],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[2],(int)rotatedpoints[3],(int)rotatedpoints[10],(int)rotatedpoints[11],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[2],(int)rotatedpoints[3],(int)rotatedpoints[6],(int)rotatedpoints[7],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[0],(int)rotatedpoints[1],(int)rotatedpoints[8],(int)rotatedpoints[9],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[4],(int)rotatedpoints[5],(int)rotatedpoints[12],(int)rotatedpoints[13],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[4],(int)rotatedpoints[5],(int)rotatedpoints[6],(int)rotatedpoints[7],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[6],(int)rotatedpoints[7],(int)rotatedpoints[14],(int)rotatedpoints[15],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[8],(int)rotatedpoints[9],(int)rotatedpoints[12],(int)rotatedpoints[13],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[8],(int)rotatedpoints[9],(int)rotatedpoints[10],(int)rotatedpoints[11],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[10],(int)rotatedpoints[11],(int)rotatedpoints[14],(int)rotatedpoints[15],0x00,0xFF,0x00);
	drawline(surface,(int)rotatedpoints[12],(int)rotatedpoints[13],(int)rotatedpoints[14],(int)rotatedpoints[15],0x00,0xFF,0x00);
}
void rotatecube(int i)
{
	float angle=PI/12;

	rotatedpoints[0]=cubepoints[0]+((cubepoints[0]-320)*cos(i*angle)-(cubepoints[1]-240)*sin(i*angle));
	rotatedpoints[1]=cubepoints[1]+((cubepoints[0]-320)*sin(i*angle)+(cubepoints[1]-240)*cos(i*angle));
	rotatedpoints[2]=cubepoints[2]+((cubepoints[2]-320)*cos(i*angle)-(cubepoints[3]-240)*sin(i*angle));
	rotatedpoints[3]=cubepoints[3]+((cubepoints[2]-320)*sin(i*angle)+(cubepoints[3]-240)*cos(i*angle));
	rotatedpoints[4]=cubepoints[4]+((cubepoints[4]-320)*cos(i*angle)-(cubepoints[5]-240)*sin(i*angle));
	rotatedpoints[5]=cubepoints[5]+((cubepoints[4]-320)*sin(i*angle)+(cubepoints[5]-240)*cos(i*angle));
	rotatedpoints[6]=cubepoints[6]+((cubepoints[6]-320)*cos(i*angle)-(cubepoints[7]-240)*sin(i*angle));
	rotatedpoints[7]=cubepoints[7]+((cubepoints[6]-320)*sin(i*angle)+(cubepoints[7]-240)*cos(i*angle));
	rotatedpoints[8]=cubepoints[8]+((cubepoints[8]-320)*cos(i*angle)-(cubepoints[9]-240)*sin(i*angle));
	rotatedpoints[9]=cubepoints[9]+((cubepoints[8]-320)*sin(i*angle)+(cubepoints[9]-240)*cos(i*angle));
	rotatedpoints[10]=cubepoints[10]+((cubepoints[10]-320)*cos(i*angle)-(cubepoints[11]-240)*sin(i*angle));
	rotatedpoints[11]=cubepoints[11]+((cubepoints[10]-320)*sin(i*angle)+(cubepoints[11]-240)*cos(i*angle));
	rotatedpoints[12]=cubepoints[12]+((cubepoints[12]-320)*cos(i*angle)-(cubepoints[13]-240)*sin(i*angle));
	rotatedpoints[13]=cubepoints[13]+((cubepoints[12]-320)*sin(i*angle)+(cubepoints[13]-240)*cos(i*angle));
	rotatedpoints[14]=cubepoints[14]+((cubepoints[14]-320)*cos(i*angle)-(cubepoints[15]-240)*sin(i*angle));
	rotatedpoints[15]=cubepoints[15]+((cubepoints[14]-320)*sin(i*angle)+(cubepoints[15]-240)*cos(i*angle));

}

int main(int argc, char* argv[])
{
	mainInit();
	SDL_Surface *screen;
	int i;


	SDL_Init(SDL_INIT_VIDEO); 
   
	screen = SDL_SetVideoMode(640,480,32,SDL_FULLSCREEN|SDL_HWSURFACE);
	
	SDL_Rect rect;
	rect.x=0;
	rect.y=0;
	rect.w=640;
	rect.h=480;

	Uint32 black=SDL_MapRGB(screen->format,0x00,0x00,0x00);

	while(1)
	{
		for(i=0;i<48;i++)
		{
			drawcube(screen);
			SDL_Flip(screen);
			SDL_Delay(100);
			SDL_FillRect(screen,&rect,black);
			rotatecube(i);
		}

	}



  
	return 0;
}






