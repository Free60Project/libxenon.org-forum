#include <stdio.h>
#include <stdlib.h>

#include <xenos/xenos.h>
#include <xenos/xe.h>
#include <xenon_sound/sound.h>
#include <diskio/dvd.h>
#include <diskio/ata.h>
#include <ppc/cache.h>
#include <ppc/timebase.h>
#include <pci/io.h>
#include <input/input.h>
#include <xenon_smc/xenon_smc.h>
#include <console/console.h>
#include <xenon_soc/xenon_power.h>
#include <usb/usbmain.h>
#include <ppc/timebase.h>


#define MAXPATHLEN 256
#define PACKAGE_VERSION "1.9"
#define PREFIX "./"

#ifndef inline
#define inline __inline__
#endif
