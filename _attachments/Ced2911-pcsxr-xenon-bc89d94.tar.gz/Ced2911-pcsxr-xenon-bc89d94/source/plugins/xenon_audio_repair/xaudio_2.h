extern void XAudio2_SetupSound();
extern void XAudio2_RemoveSound();
