int x_thread_wait(int thread);
int x_thread_cancel(int thread);
int x_thread_create(int thread,void *task);

