#include <ppc/timebase.h>

void ShowFPS();