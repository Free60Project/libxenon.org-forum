#include "config.h"
#include "debug.h"
#include <ppc/timebase.h>

#ifndef PCSXDF
void DebugVSync() {
    //ShowFPS();
}
void ProcessDebug(){
    
}
void DebugCheckBP(u32 address, enum breakpoint_types type){
    
}
#endif