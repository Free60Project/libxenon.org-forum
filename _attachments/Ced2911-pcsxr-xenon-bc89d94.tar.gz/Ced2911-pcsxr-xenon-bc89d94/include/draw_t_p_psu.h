extern const u8 draw_t_p_psu_end[];
extern const u8 draw_t_p_psu[];
extern const u32 draw_t_p_psu_size;
