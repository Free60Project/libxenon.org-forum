#include <stdio.h>
#include <stdlib.h>

#include <xenos/xenos.h>
#include <xenos/xe.h>
#include <xenon_sound/sound.h>
#include <diskio/ata.h>
#include <ppc/cache.h>
#include <ppc/timebase.h>
#include <pci/io.h>
#include <input/input.h>
#include <xenon_smc/xenon_smc.h>
#include <console/console.h>
#include <xenon_soc/xenon_power.h>
#include <usb/usbmain.h>
#include <ppc/timebase.h>


#define BP {printf("[Breakpoint] in function %s, line %d, file %s\n",__FUNCTION__,__LINE__,__FILE__);getch();}
#define TR {printf("[Trace] in function %s, line %d, file %s\n",__FUNCTION__,__LINE__,__FILE__);}

#define MAXPATHLEN 256
#define PACKAGE_VERSION "1.9"
#define PREFIX "./"

#ifndef inline
#define inline __inline__
#endif

#define ALIGNED_128 __attribute__((aligned(128)))
#define ALIGNED_32 __attribute__((aligned(32)))
#define ALIGNED ALIGNED_128
