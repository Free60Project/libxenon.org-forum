#include "Gui.h"

int main(){
	ZLX::Gui MyGui;
	MyGui.Run("..\\ressources\\");
}