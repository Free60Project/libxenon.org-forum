#include "Browser.h"

extern ZLX::Browser App;
