void ActionBootTFTP(void * unused);
void ActionShutdown(void * unused);
void ActionRestart(void * unused);
void ActionDumpNand(void * unused);
void ActionReturnToXell(void * unused);
void ActionStartHttpd(void * unused);

void ActionFlashNand(const char * filename);
void ActionLaunchElf(const char * filename);
void ActionLaunchFile(char * filename);
