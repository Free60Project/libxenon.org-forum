//save some space
#if 0
int printf ( const char * format, ... ){
    return 0;
}
void putch(unsigned char c){};

#endif