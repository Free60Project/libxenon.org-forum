#pragma once
#include "zlx.h"
// Class to allow draw sprite, and other simple primitives
namespace ZLX {

    class Draw {
    public:
        static void DrawTexturedRect(float x, float y, float w, float h, ZLXTexture * p_texture);
        static void DrawColoredRect(float x, float y, float w, float h, ZLXColor color);
        static void DrawGradientRect(float x, float y, float w, float h, ZLXColor TopColor, ZLXColor BackColor);
        static void Reset();

    };

}