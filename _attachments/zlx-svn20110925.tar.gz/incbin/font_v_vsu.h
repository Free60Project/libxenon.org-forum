extern const u8 font_v_vsu_end[];
extern const u8 font_v_vsu[];
extern const u32 font_v_vsu_size;
