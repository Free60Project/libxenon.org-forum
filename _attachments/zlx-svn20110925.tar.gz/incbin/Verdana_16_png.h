extern const u8 Verdana_16_png_end[];
extern const u8 Verdana_16_png[];
extern const u32 Verdana_16_png_size;
