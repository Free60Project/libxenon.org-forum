extern const u8 draw_v_vsu_end[];
extern const u8 draw_v_vsu[];
extern const u32 draw_v_vsu_size;
