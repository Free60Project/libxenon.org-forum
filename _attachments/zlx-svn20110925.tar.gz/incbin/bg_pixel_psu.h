extern const u8 bg_pixel_psu_end[];
extern const u8 bg_pixel_psu[];
extern const u32 bg_pixel_psu_size;
