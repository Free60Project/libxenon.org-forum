extern const u8 bg_vertex_vsu_end[];
extern const u8 bg_vertex_vsu[];
extern const u32 bg_vertex_vsu_size;
