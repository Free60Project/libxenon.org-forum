extern const u8 Verdana_16_abc_end[];
extern const u8 Verdana_16_abc[];
extern const u32 Verdana_16_abc_size;
