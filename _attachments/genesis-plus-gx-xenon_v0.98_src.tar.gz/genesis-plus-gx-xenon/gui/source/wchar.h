#ifdef __cplusplus
extern "C"
{
#endif
    wchar_t * wcsdup(const wchar_t *str);
    size_t wcslen(const wchar_t *s);
    wchar_t *wcscpy(wchar_t *s1, const wchar_t *s2);

#ifdef __cplusplus
}
#endif
