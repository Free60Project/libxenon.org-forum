#include <input/input.h>
#include <usb/usbmain.h>
void SYSInputReset();
void SYSInputUpdate();