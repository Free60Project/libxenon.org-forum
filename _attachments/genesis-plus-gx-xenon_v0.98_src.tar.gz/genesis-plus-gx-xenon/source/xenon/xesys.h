void SYSInit();
void SYSClose();
void SYSUpdate();

int SYSGetStatesNumber();
void SYSSelectStates(int n);
void SYSSaveState();
void SYSLoadState();
