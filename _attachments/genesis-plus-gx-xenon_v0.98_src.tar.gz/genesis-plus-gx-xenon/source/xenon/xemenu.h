void SYSMenuInit();
void SYSMenuUpdate();
void SYSMenuEnable(int enable);
void SYSMenuDisplayString( char * format, ... );