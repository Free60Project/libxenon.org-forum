
#ifndef _MAIN_H_
#define _MAIN_H_

#define MAX_INPUTS 8
void osd_input_Update();
extern int debug_on;
extern int log_error;

#endif /* _MAIN_H_ */
