Pcsxr 0.62

==================================================
= Recompiled by Swizzy for Corona 2014-01-08     =
= Sourcecode can be found @ libxenon github:     =
= https://github.com/LibXenonProject/pcsxr-xenon =
==================================================

Remove ext2/3/4, ntfs support (red screen on some setup)

Bug fixe on gpu plugin

------------------------------------------------------------------

Pcsxr 0.6

New gpu plugin, allow to play game in hd !!

Load game from fat, ext2/3/4, ntfs device

Save states support

Thanks,

Gligli, Razkar, Tuxuser, [c0z], lantus, all the libxenon-dev team