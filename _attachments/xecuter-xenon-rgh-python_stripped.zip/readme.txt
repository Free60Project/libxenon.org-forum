Here is the build.py for Xecuter's Xenon RGH Hack

J-Runner has no use for build.py as it doesn't use Python (or Nandpro) but figured there would be some
guys out there who still use this method.

Thanks to: 

RF1911 for the Xenon SMC
GliGli & Tiros for the original build.py
cOz for the Universal patch
To the Xecuter RGH team - you know who you are.

Greets to:
#libxenon #FreeStyleDash #freeboot #rgloader #J-Runner #JungleFlasher #c4e

