#include <stdio.h>
#include <xenos/xenos.h>
#include <console/console.h>
#include <math.h>
#include <SDL/SDL.h>

#define	PI	3.14159265358979323846

		    //Ax  Ay  Bx  By  Cx  Cy  Dx  Dy  Ex  Ey  Fx  Fy  Gx  Gy  Hx  Hy
float cubepoints[16]={300,220,340,220,300,260,340,260,280,200,320,200,280,240,320,240};
float rotdpoints[16];

void mainInit(){
	xenos_init(VIDEO_MODE_AUTO);
	console_init();

	kmem_init();
	usb_init();
	usb_do_poll();
}


void drawline(SDL_Surface *surface, int x1, int y1, int x2, int y2, Uint8 r, Uint8 g, Uint8 b)
{
	if ( SDL_MUSTLOCK(surface) ) 
	{
		if ( SDL_LockSurface(surface) < 0 ) 
		{
			fprintf(stderr, "Can't lock screen: %s\n", SDL_GetError());
			SDL_Quit();
		}
	}

	Uint32 color=SDL_MapRGB(surface->format, r, g, b );
	Sint16 dx, dy, sdx, sdy, x, y;

	dx = x2 - x1;
	dy = y2 - y1;

	sdx = (dx < 0) ? -1 : 1;
	sdy = (dy < 0) ? -1 : 1;

	dx = sdx * dx + 1;
	dy = sdy * dy + 1;

	x = y = 0;

	Sint16 pixx = surface->format->BytesPerPixel;
	Sint16 pixy = surface->pitch;
	Uint8 *pixel = (Uint8*)surface->pixels + y1*pixy + x1*pixx;

	pixx *= sdx;
	pixy *= sdy;

	if (dx < dy)
	{
		Sint32 tmp = dx;
		dx = dy;
		dy = (Sint16)(tmp);
		tmp = pixx;
		pixx = pixy;
		pixy = tmp;
	}



	for (x=0; x < dx; x++)
	{
		*(Uint32*)pixel = color;

		y += dy;
		if (y >= dx)
		{
			y -= dx;
			pixel += pixy;
		}
		pixel += pixx;
	}

	if ( SDL_MUSTLOCK(surface) )
	{
		SDL_UnlockSurface(surface);
	}

}

void drawcube(SDL_Surface *surface)
{
	drawline(surface,(int)rotdpoints[0],(int)rotdpoints[1],(int)rotdpoints[8],(int)rotdpoints[9],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[0],(int)rotdpoints[1],(int)rotdpoints[2],(int)rotdpoints[3],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[0],(int)rotdpoints[1],(int)rotdpoints[4],(int)rotdpoints[5],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[2],(int)rotdpoints[3],(int)rotdpoints[10],(int)rotdpoints[11],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[2],(int)rotdpoints[3],(int)rotdpoints[6],(int)rotdpoints[7],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[0],(int)rotdpoints[1],(int)rotdpoints[8],(int)rotdpoints[9],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[4],(int)rotdpoints[5],(int)rotdpoints[12],(int)rotdpoints[13],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[4],(int)rotdpoints[5],(int)rotdpoints[6],(int)rotdpoints[7],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[6],(int)rotdpoints[7],(int)rotdpoints[14],(int)rotdpoints[15],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[8],(int)rotdpoints[9],(int)rotdpoints[12],(int)rotdpoints[13],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[8],(int)rotdpoints[9],(int)rotdpoints[10],(int)rotdpoints[11],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[10],(int)rotdpoints[11],(int)rotdpoints[14],(int)rotdpoints[15],0x00,0xff,0x00);
	drawline(surface,(int)rotdpoints[12],(int)rotdpoints[13],(int)rotdpoints[14],(int)rotdpoints[15],0x00,0xff,0x00);
}



int main(int argc, char* argv[])
{
	mainInit();
	SDL_Surface *screen;
	int i;
	float angle=PI/12;

	SDL_Init(SDL_INIT_VIDEO); 
   
	screen = SDL_SetVideoMode(640,480,32,SDL_FULLSCREEN|SDL_HWSURFACE);

	SDL_Rect rect;
	rect.x=0;
	rect.y=0;
	rect.w=640;
	rect.h=480;
	Uint32 black=SDL_MapRGB(screen->format,0x00,0x00,0x00);


	while(1)
	{	
	for(i=0;i<24;i++)
	{
		//calculate rotated points
		rotdpoints[0]=(cubepoints[0]-320)*cos(i*angle)-(cubepoints[1]-240)*sin(i*angle)+320;
		rotdpoints[1]=(cubepoints[1]-240)*cos(i*angle)+(cubepoints[0]-320)*sin(i*angle)+240;
		rotdpoints[2]=(cubepoints[2]-320)*cos(i*angle)-(cubepoints[3]-240)*sin(i*angle)+320;
		rotdpoints[3]=(cubepoints[3]-240)*cos(i*angle)+(cubepoints[2]-320)*sin(i*angle)+240;
		rotdpoints[4]=(cubepoints[4]-320)*cos(i*angle)-(cubepoints[5]-240)*sin(i*angle)+320;
		rotdpoints[5]=(cubepoints[5]-240)*cos(i*angle)+(cubepoints[4]-320)*sin(i*angle)+240;
		rotdpoints[6]=(cubepoints[6]-320)*cos(i*angle)-(cubepoints[7]-240)*sin(i*angle)+320;
		rotdpoints[7]=(cubepoints[7]-240)*cos(i*angle)+(cubepoints[6]-320)*sin(i*angle)+240;
		rotdpoints[8]=(cubepoints[8]-320)*cos(i*angle)-(cubepoints[9]-240)*sin(i*angle)+320;
		rotdpoints[9]=(cubepoints[9]-240)*cos(i*angle)+(cubepoints[8]-320)*sin(i*angle)+240;
		rotdpoints[10]=(cubepoints[10]-320)*cos(i*angle)-(cubepoints[11]-240)*sin(i*angle)+320;
		rotdpoints[11]=(cubepoints[11]-240)*cos(i*angle)+(cubepoints[10]-320)*sin(i*angle)+240;
		rotdpoints[12]=(cubepoints[12]-320)*cos(i*angle)-(cubepoints[13]-240)*sin(i*angle)+320;
		rotdpoints[13]=(cubepoints[13]-240)*cos(i*angle)+(cubepoints[12]-320)*sin(i*angle)+240;
		rotdpoints[14]=(cubepoints[14]-320)*cos(i*angle)-(cubepoints[15]-240)*sin(i*angle)+320;
		rotdpoints[15]=(cubepoints[15]-240)*cos(i*angle)+(cubepoints[14]-320)*sin(i*angle)+240;

		//draw cube
		drawcube(screen);
		SDL_UpdateRect(screen,0,0,0,0);
		SDL_Delay(50);
		SDL_FillRect(screen,&rect,black);
	}

	}

  
	return 0;
}






