/*
 * xrick/src/xrick.c
 *
 * Copyright (C) 1998-2002 BigOrno (bigorno@bigorno.net). All rights reserved.
 *
 * The use and distribution terms for this software are contained in the file
 * named README, which can be found in the root of this distribution. By
 * using this software in any fashion, you are agreeing to be bound by the
 * terms of this license.
 *
 * You must not remove this notice, or any other, from this software.
 */

#include "system.h"
#include "game.h"

#include <SDL/SDL.h>

#include <xenos/xe.h>
#include <xenos/xenos.h>
#include <xenos/edram.h>
#include <xenos/xenos.h>
#include <xenon_sound/sound.h>
#include <usb/usbmain.h>
#include <libfat/fat.h>
#include <console/console.h>
#include <xenon_smc/xenon_smc.h>
#include <xenon_soc/xenon_power.h>

#include <ppc/timebase.h>
#include <time/time.h>
#include <diskio/ata.h>

/*
 * main
 */
int
main(int argc, char *argv[])
{
	xenos_init(VIDEO_MODE_AUTO);
	console_init();
    
    	xenon_sound_init();

    	xenon_make_it_faster(XENON_SPEED_FULL);
	usb_init();
	usb_do_poll();

	xenon_ata_init();
    
	fatInitDefault();

	sys_init(argc, argv);
	if (sysarg_args_data)
		data_setpath(sysarg_args_data);
	else
		data_setpath("uda:/data.zip");
	game_run();
	data_closepath();
	sys_shutdown();
	return 0;
}

/* eof */
