
void videoInit(void);
void videoBlit(int xres, int yres);

