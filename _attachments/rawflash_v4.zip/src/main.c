#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xenos/xe.h>
#include <xenos/xenos.h>

#include <console/console.h>
#include <usb/usbmain.h>
#include <xenon_nand/xenon_sfcx.h>

int flashdone = 0;
unsigned char* blockbuf;

int writeImage(int len, int f)
{
	int i=0;
	int secondPgOffset = sfc.page_sz_phys;
	int addr, addrphy, status, r;
	int readsz = sfc.pages_in_block*sfc.page_sz_phys;
	int numblocks = (len/sfc.block_sz_phys);
	blockbuf = malloc(readsz);
	if(blockbuf == NULL)
	{
		printf("ERROR: unable to allocate 0x%x bytes for a buffer!\n", readsz);
		return 0;
	}
	if(sfc.meta_type == META_TYPE_2)
		secondPgOffset = 0x1080; // 0x210*8
	while(i < numblocks)
	{
		printf("processing block 0x%04x of 0x%04x    \r", i+1, numblocks);
		addr = i*sfc.block_sz;
		// check first two pages of each block to find out if it's a good block
		status = sfcx_read_block(blockbuf, addr, 1);
		if((sfcx_is_pagevalid(blockbuf) == 0) || (sfcx_is_pagevalid(&blockbuf[secondPgOffset]) == 0))
			status = status | STATUS_BB_ER;
		r = read(f, blockbuf, readsz);
		if (r < 0)
		{
			printf("ERROR: failed to read %d bytes from file\n\n",readsz);
			return 0;
		}
		if((status & (STATUS_BB_ER|STATUS_ECC_ER)) == 0)
		{
			addr = i*sfc.block_sz_phys;
			addrphy = i*sfc.block_sz;
			sfcx_erase_block(addrphy);
			sfcx_write_block(blockbuf, addrphy);
		}
		else
			printf("block 0x%x seems bad, status 0x%08x\n", i, status);
		i++;
	}
	printf("\n\n");
	return 1;
}

int flashImage(char *filename)
{
	struct stat s;
	int size;
	int f = open(filename, O_RDONLY);
	if (f < 0)
	{
		return f;
	}
	flashdone = 1;

	fstat(f, &s);
	size = s.st_size;
	if((size == (RAW_NAND_64*4)) || (size == (RAW_NAND_64*8))) // 256 or 512M NAND image, only flash 64M
	{
		size = RAW_NAND_64;
	}
	else if((size != 0x1080000)&& (size != RAW_NAND_64)) // 16 M size
	{
		printf("error: %s - size %d is not valid image size!\n", filename, size);
		close(f);
		return 0;
	}

	printf("%s opened OK, attempting to write 0x%x bytes to flash...\n",filename, size);
	if(writeImage(size, f) == 1)
		printf("image written, shut down now!\n");
	else
		printf("failed to write image :(\n");

	close(f);
	if(blockbuf != NULL)
		free(blockbuf);
	return 0;
}


int main (void)
{
	xenos_init(VIDEO_MODE_AUTO);
	console_set_colors(0x00000000, 0xFFFFFFFF);
	console_init();
	printf("rawflash started\n");

	printf("initializing NAND\n");
	sfcx_init();
	if (sfc.initialized != SFCX_INITIALIZED)
	{
		printf("NAND init failed! <STOP>\n");
		while(1);
	}
	
	printf("   NAND:page_sz         = %08X\n", sfc.page_sz);
	printf("   NAND:meta_sz         = %08X\n", sfc.meta_sz);
	printf("   NAND:page_sz_phys    = %08X\n", sfc.page_sz_phys);

	printf("   NAND:pages_in_block  = %08X\n", sfc.pages_in_block);
	printf("   NAND:block_sz        = %08X\n", sfc.block_sz);
	printf("   NAND:block_sz_phys   = %08X\n", sfc.block_sz_phys);

	printf("   NAND:size_mb         = %dMB\n", sfc.size_mb);
	printf("   NAND:size_bytes      = %08X\n", sfc.size_bytes);
	printf("   NAND:size_bytes_phys = %08X\n", sfc.size_bytes_phys);

	printf("   NAND:size_pages      = %08X\n", sfc.size_pages);
	printf("   NAND:size_blocks     = %08X\n\n", sfc.size_blocks);


	printf("initializing usb\n");
	usb_init();
	usb_do_poll();

	while(1){
		usb_do_poll();
		if(flashdone == 0)
			flashImage("uda:/nandflash.bin");

	}
}
