
#ifndef _OSD_H_
#define _OSD_H_

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#include "SDL.h"
#include <stdlib.h>

#include "gperror.h"
#include "shared.h"
#include "main.h"

#endif /* _OSD_H_ */
