
#ifndef _MEMVDP_H_
#define _MEMVDP_H_

/* Function prototypes */
unsigned int vdp_dma_r(unsigned int address);

#endif /* _MEMVDP_H_ */
