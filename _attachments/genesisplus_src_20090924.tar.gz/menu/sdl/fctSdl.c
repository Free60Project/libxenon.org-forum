/**
Function Utiliser pour l'ecriture, creation de surface et l'initialisation de sdl
**/
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <SDL/SDL.h>
#include <input/input.h>
#include "video.h"
#include <xenos/xe.h>
#include "fctSdl.h"
#include "bitmap/bitmap.h"
#include "bitmap/font.h"
#include "png/IMG_png.h"
#define u8 unsigned char;
#define u32 int;
#include "bg_png.h"
#include "file_png.h"
#include "folder_png.h"
#include "star_png.h"
/**
Initialisation de l'ecran
**/
void initSDLScreen()
{
	printf("\t\t\tCréation des textures ...!!\n");
	//Texture frequement utilisé
	printf("\t\t\tXeGetFont(); ...!!\n");
	XeFont=XeGetFont();
	printf("\t\t\tXeGetBitmapFromMemory(); ...!!\n");
	//XeBackground=XeGetBitmapFromMemory(1280,720,background);
	//XeFileIcon=XeGetBitmapFromMemory(64,64,xenonFileData);
	//XeFolderIcon=XeGetBitmapFromMemory(64,64,xenonFolderData);
	//XeCursor=XeGetBitmapFromMemory(64,64,xenonCursorData);
	if(XeBackground=loadPNG("uda:/mdbg.png")==0)
	{
		XeBackground=loadPNGFromMemory(bg_png);
	}	
	if(XeFileIcon=loadPNG("uda:/mdfile.png")==0)
	{
		XeFileIcon=loadPNGFromMemory(file_png);
	}
	if(XeFolderIcon=loadPNG("uda:/mddir.png")==0)
	{
		XeFolderIcon=loadPNGFromMemory(folder_png);
	}
	if(XeCursor=loadPNG("uda:/mdcurs.png")==0)
	{
		XeCursor=loadPNGFromMemory(star_png);
	}

	printf("\t\t\tCa marche !!\n");
}


//Copie SDLScreen dans gfxplane (à faire avant affichage)
void updateGFXPlane()
{
	//unsigned long size=(SDLScreen->w)*(SDLScreen->h)*(4) + 1;
	//memcpy(gfxplane->base,SDLScreen->pixels,size);
}

struct XenosSurface * XeGetBitmapFromMemory(int width,int height,void *pixeldata)
{
	printf("\t\t\tXeGetBitmapFromMemory(int width,int height,void *pixeldata) ...!!\n");
	struct XenosSurface *surface = Xe_CreateTexture(xe, width, height, 1, XE_FMT_8888 | XE_FMT_ARGB, 0);
	Xe_Surface_LockRect(xe, surface, 0, 0, 0, 0, XE_LOCK_WRITE);
	unsigned long size=(surface->height)*(surface->pitch) + 1;
	printf("\t\t\tmemcpy ...!!\n");
	memcpy(surface->base,pixeldata,size);//Copie la texture en mémoire dans la surface xe
	Xe_Surface_Unlock(xe, surface);
	return surface;
}

struct XenosSurface * XeGetFont()
{
	struct XenosSurface *font = Xe_CreateTexture(xe, 256, 256, 1, XE_FMT_8, 0);
	uint32_t *data = (uint32_t*)Xe_Surface_LockRect(xe, font, 0, 0, 0, 0, XE_LOCK_WRITE);
	memcpy(data, fontdata, sizeof(fontdata));
	Xe_Surface_Unlock(xe, font);
	return font;
}


void XeDrawSurface2(struct XenosSurface *txt, float dstx, float dsty, float width, float height, int withalpha)
{
	float uleft = 0, uright = 1, vtop = 0, vbottom = 1;

	float logo[] = {
		dstx,       dsty + height, uleft,  vtop,
		dstx+width, dsty + height, uright, vtop,
		dstx,       dsty,          uleft,  vbottom,

		dstx,       dsty,          uleft,  vbottom,
		dstx+width, dsty + height, uright, vtop,
		dstx+width, dsty,          uright, vbottom
	};
	
	Xe_VBBegin(xe, 4);
	Xe_VBPut(xe, logo, 6 * 4);
	
	struct XenosVertexBuffer *vb = Xe_VBEnd(xe);
	Xe_VBPoolAdd(xe, vb);
	
	if (withalpha)
	{
		Xe_SetSrcBlend(xe, XE_BLEND_SRCALPHA);
		Xe_SetDestBlend(xe, XE_BLEND_INVSRCALPHA);
		Xe_SetBlendOp(xe, XE_BLENDOP_ADD);
	} else
	{
		Xe_SetSrcBlend(xe, XE_BLEND_ONE);
		Xe_SetDestBlend(xe, XE_BLEND_ZERO);
		Xe_SetBlendOp(xe, XE_BLENDOP_ADD);
	}

	Xe_SetShader(xe, SHADER_TYPE_PIXEL, sh_ps, 0);
	Xe_SetShader(xe, SHADER_TYPE_VERTEX, sh_vs, 0);
	Xe_SetTexture(xe, 0, txt);
	Xe_Draw(xe, vb, 0);
}

//Garde l'aspect ratio :)
void XeDrawSurface(struct XenosSurface *txt, float dstx, float dsty, float scale, int withalpha)
{
	//(xe->tex_fb)=texture du framebuffer

	float height=(txt->height);
	height=(height/xe->tex_fb.height)*scale;

	float width=(txt->width);
	width=(width/xe->tex_fb.width)*scale;
	//float width=scale;

	float uleft = 0, uright = 1, vtop = 0, vbottom = 1;

	float logo[] = {
		dstx,       dsty + height, uleft,  vtop,
		dstx+width, dsty + height, uright, vtop,
		dstx,       dsty,          uleft,  vbottom,

		dstx,       dsty,          uleft,  vbottom,
		dstx+width, dsty + height, uright, vtop,
		dstx+width, dsty,          uright, vbottom
	};
	
	Xe_VBBegin(xe, 4);
	Xe_VBPut(xe, logo, 6 * 4);
	
	struct XenosVertexBuffer *vb = Xe_VBEnd(xe);
	Xe_VBPoolAdd(xe, vb);
	
	if (withalpha)
	{
		Xe_SetSrcBlend(xe, XE_BLEND_SRCALPHA);
		Xe_SetDestBlend(xe, XE_BLEND_INVSRCALPHA);
		Xe_SetBlendOp(xe, XE_BLENDOP_ADD);
	} else
	{
		Xe_SetSrcBlend(xe, XE_BLEND_ONE);
		Xe_SetDestBlend(xe, XE_BLEND_ZERO);
		Xe_SetBlendOp(xe, XE_BLENDOP_ADD);
	}

	Xe_SetShader(xe, SHADER_TYPE_PIXEL, sh_ps, 0);
	Xe_SetShader(xe, SHADER_TYPE_VERTEX, sh_vs, 0);
	Xe_SetTexture(xe, 0, txt);
	Xe_Draw(xe, vb, 0);
}

void  XePrintf(float dstx, float dsty, const char *text, float scale, uint32_t icolor)
{
	if (!*text)
		return 0;
	Xe_VBBegin(xe, 5);

	while (*text)
	{
		struct fontentry *f = &fontentries[(unsigned char)*text++];
		if (!f->width)
			continue;
		
		float u = f->x / 256.0;
		float v = f->y / 256.0;

		float uw = f->width / 256.0;
		float vw = f->height / 256.0;
		
		float width = uw * scale, height = vw * scale;
		
		float xo = f->xoffset / 256.0 * scale;
		float yo = f->yoffset / 256.0 * scale;
		
		float left = dstx + xo, top = dsty - yo, right = dstx + width, bottom = dsty - yo - height;
		
		union
		{
			float color;
			int icolor;
		} un;
		
		un.icolor = icolor;
		
		float color = un.color;
		
		float letter[] = {
			left,  top,      u,    v,     color,
			right, top,      u+uw, v,     color,
			left,  bottom,   u,    v+vw,  color,

			left,  bottom,   u,    v+vw,  color,
			right, top,      u+uw, v,     color,
			right, bottom,   u+uw, v+vw,  color,
		};
		
		Xe_VBPut(xe, letter, 6 * 5);
		
		dstx += f->xadvance / 256.0 * scale;
	}

	struct XenosVertexBuffer *vb = Xe_VBEnd(xe);
	Xe_VBPoolAdd(xe, vb);

	Xe_SetSrcBlend(xe, XE_BLEND_SRCALPHA);
	Xe_SetDestBlend(xe, XE_BLEND_INVSRCALPHA);
	Xe_SetBlendOp(xe, XE_BLENDOP_ADD);

	Xe_SetShader(xe, SHADER_TYPE_PIXEL, sh_font_ps, 0);
	Xe_SetShader(xe, SHADER_TYPE_VERTEX, sh_font_vs, 0);
	Xe_SetTexture(xe, 0, XeFont);
	Xe_Draw(xe, vb, 0);
	
	return dstx;
}


/**
Effectue un printf rapide avec effaement de couleur/ et rafraichissement

**/
void fastPrintf(int x,int y, int color, char *str)
{
/*
	SDL_FillRect(SDLScreen,NULL,color);//Efface l'ecran
	SDLprintf(SDLScreen,x,y,str);//Ecritle texte
	updateGFXPlane();//mets à jour
	drawBg(1280,720);
	updateScreen(1280,720);
*/ 
	Xe_InvalidateState(xe);
	XePrintf(-0.5, 0,str, 0.6, 0x0000FF);//Red
#if 1
	//Blanc ....
	Xe_SetClearColor(xe, ~0);
	Xe_Resolve(xe);

	while (!Xe_IsVBlank(xe));
	Xe_Sync(xe);
#endif
}

