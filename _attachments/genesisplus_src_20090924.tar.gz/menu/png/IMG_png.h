struct XenosSurface *loadPNG(const char *filename);

struct pngMem{
	unsigned char *png_end;
	unsigned char *data;
	int size;
	int offset;//pour le parcours
};

struct XenosSurface *loadPNGFromMemory( unsigned char *data );
