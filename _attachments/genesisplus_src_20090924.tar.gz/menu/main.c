#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <input/input.h>
#include <time/time.h>
#include <ppc/timebase.h>
#include <newlib/dirent.h>
#include <xenos/xe.h>

#include "video.h"
#include "main.h"
#include "fctSdl.h"

//les textures
#include "bitmap/bitmap.h"

/***
ETAT DE L'APPLICATION
***/
dirInfo_s dirInfo;
/**
Lance l'emulateur ....
**/
void doEmulation()
{
	char newDir[256];
	sprintf(newDir,"%s/%s",dirInfo.currentDirname,dirInfo.node[iSelectedItem].name);
	megadrivemain(cleanDirname(newDir));
}

/**
Une action est a realisé
**/
void HandleAction()
{
	if(dirInfo.node[iSelectedItem].type==1)//Dir
	{
		
		char newDir[256];
		sprintf(newDir,"%s/%s",dirInfo.currentDirname,dirInfo.node[iSelectedItem].name);
		//updateCurDir(newDir);
		listFile(1,newDir);//mets a jour ....
	}
	if(dirInfo.node[iSelectedItem].type==0)//A tester si c une rom !!
	{
		
//		updateCurDir(newDir);
		emuLoaded=1;
	}
}

//Liste un dossier
void listFile(int refresh,char *newdirname)
{
	if(refresh)
	{
		dirInfo=updateCurDir(newdirname);

	}
	dirInfo_s directory=dirInfo;

	if(dirInfo.count>0)
	{
		int i;

		int iStart;//=0;
		int iEnd;//=nItemOnScreen;
		int NBPage=ceil(dirInfo.count/nItemOnScreen);//Nombre de pages
		int selPage=iSelectedItem/nItemOnScreen;//Page selectionner

		if(selPage>NBPage)
		{
			selPage=NBPage;
		}

		iStart=	selPage*nItemOnScreen;
		iEnd=iStart+(nItemOnScreen-1);
		if(iEnd>=dirInfo.count)
		{
			if(dirInfo.count>0)
				iEnd=dirInfo.count-1;
			else
				iEnd=0;
		}

		int z=0;
		//printf("Affiche la page:%d/%d\niSelectedItem=%d\t selPage=%d\t iStart=%d\tiEnd=%d\tCount=%d\n",selPage , NBPage, iSelectedItem ,selPage, iStart, iEnd,FatLS.count );
		for(i=iStart;	i<=iEnd;	i++)
		{
			float scale=1;
			int	color=0xaaaaaa;
			if(i==iSelectedItem)
			{
				scale=bound(xe_framecount)+1.2f;
				color=0xffffff;
			}
			const char dname[256];

			sprintf(dname,"%s",directory.node[i].name);

			//Affiche le nom de fichier
			XePrintf(-.4,((ROWHEIGHT*(z)+DECALAGEROWS)+0.125),dname,scale*0.8,color);

			if(directory.node[i].type==0)
			{
				XeDrawSurface(XeFileIcon, -.6, (ROWHEIGHT*z)+DECALAGEROWS, .5*scale, 1);
			}
			else
			{
				XeDrawSurface(XeFolderIcon, -.6, (ROWHEIGHT*z)+DECALAGEROWS, .5*scale, 1);
			}
			z++;
	
		}
	}
	else
	{
		//Aucun fichier trouver
		//SDLprintf(SDLScreen,340,200,"No file found");
		XePrintf(0.1,(0.5),"No file Found");
	}	
	//Libere les ressources
}



/**
Ecrit le menu dans SDLScreen
**/
void DrawMenu()
{
	//Dessine le background
	//XeDrawSurface(XeBackground,0,0,
	Xe_InvalidateState(xe);

	
	XeDrawSurface2(XeBackground, -1, -1, 2, 2, 0);

	//updateAnim();

	//listFile(dirInfo);//Liste les fichiers
	listFile(0,"");//Liste les fichiers

	//XeDrawSurface(XeCursor, -.75, (ROWHEIGHT*(iSelectedItem%nItemOnScreen))+DECALAGEROWS, .2, .2, 1);

#if 1
	xe_framecount+=1.0f;

	//Blanc ....
	Xe_SetClearColor(xe, ~0);
	Xe_Resolve(xe);

	while (!Xe_IsVBlank(xe));
	Xe_Sync(xe);
#endif
}



//eteint la console
void shutdown()
{
	xenon_smc_power_shutdown();
}


//Créer une valeur de rebonds a partir d'une valeur (entre 0 et 2)
float bound(int f)
{
	float time=f/300.0f;//obtient une valeur reel
	float ampl = 0.2f; // amplitude en pixel
	int freq = 3; // oscillations par seconde
	int decroi = 1; // facteur décroissance
	float u = ampl * sin(freq * time * 2 * BOUND_PI) * exp(- decroi * time);
	return u;
}

short animesense=1;
//Desine une animation ....
void updateAnim()
{
	//void XeDrawSurface(struct XenosSurface *txt, float dstx, float dsty, float scale, int withalpha)

	//XeDrawSurface(XeCursor,0.4f,0.3f,bound(xe_framecount)+1.0f,1);
	//printf("\t\t\t\t%f\n",bound(xe_framecount));
}

/***
Frameskipping
***/

static unsigned long long prev, now;

static unsigned long long gettime(void)
{
        return mftb();
}

static int diff_usec(unsigned long long prev, unsigned long long now)
{
        return (now - prev) /(PPC_TIMEBASE_FREQ/1000000);
}

//Attends jusqu'a la prochaine frame
static int menuframeSkip()
{
	int fpshz=(1) ? 16667 : 20000;//16667
	now=gettime();

	unsigned long diff=diff_usec(prev,now);


        while (diff_usec(prev, now) < fpshz)
        {
                now = gettime();
                udelay(50);
        }
	
	prev = now;
}

void mainInit()
{
	//Init Var
	iSelectedItem=0;//Item Selectionner
	emuLoaded=0;

	//init
	xenos_init();
	//console_init();
	xenon_sound_init();

	kmem_init();
	usb_init();
	usb_do_poll();
	//
	initScreen(1280,720);
	initSDLScreen();
	
	drawBg(1280,720);
	//updateScreen(1280,720);
	usb_do_poll();
}

//A ne faire qu'une seul fois
void firstInit()
{
	xenon_smc_set_led(0x01, 0x10);

	xenon_thread_startup();
	xenon_make_it_faster(1);
	xenon_sleep_thread(1);
	xenon_sleep_thread(3);
	xenon_sleep_thread(4);
	xenon_sleep_thread(5);
}

void menu()
{

	//usb_do_poll(); // pas besoin ?!

	//Se place à la racine de la premiere clef usb
	//updateCurDir("uda:");
	listFile(1,"uda:");
	emuLoaded=0;//Emu pas lancer car on est dans le menu

	
	//On affiche une premiere fois
	DrawMenu();//Dessine le menu (list des fichiers)


	//Boucle du menu
	while(emuLoaded==0)
	{
		struct controller_data_s c;
		if (get_controller_data(&c, 0))
		{
			pushBtn(c);
		}
		DrawMenu();//Dessine le menu (list des fichiers)
		menuframeSkip();
		usb_do_poll();
	}
	//Lance l'emulation et quitte cette boucle
	doEmulation();
	//Emulation quitter
	emuLoaded=0;
}

/**
Le but principal est de jamais quitter le main
**/
int main(void)
{
	mainInit();
	firstInit();
	while(1)
	{
		//Affiche le menu
		menu();
		//Menu quitter on reinitialise le menu pour le prochain tour
		mainInit();
		
	}
	return 0;
}
