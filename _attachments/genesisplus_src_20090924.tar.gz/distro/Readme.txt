Introduction:
  Genesis Plus is a freeware, open-source, portable emulator for the Genesis and MegaDrive consoles 

Changelog:
    v240909: 	First public release
		Sound doesn't work as it should ....
		It support bin and zip file but rom in smd format doesn'work
		UI updatted and support skinning:
		  Background:	uda:/mdbg.png
		  File Icon:	uda:/mdfile.png
		  Folder Icon:  uda:/mddir.png

Contact:
  http://ced2911.wata.fr | cedric2911@free.fr

Thanks:
  Tmbinc
  Jc
  Relapse
  And all people in #free60
  Authors of Genesis Plus Wii and Dc
  Charles MacDonald