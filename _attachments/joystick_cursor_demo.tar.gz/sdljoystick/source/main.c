#include <stdio.h>
#include <xenos/xenos.h>
#include <console/console.h>
#include <SDL/SDL.h>





void mainInit(){
	xenos_init(VIDEO_MODE_AUTO);
	console_init();

	kmem_init();
	usb_init();
	usb_do_poll();
}



int main(int argc, char* argv[])
{
	mainInit();
	SDL_Surface *screen;
	SDL_Joystick *joystick;
	SDL_Event event;
	int x=320,y=240;
	int xvel=0,yvel=0;

 	int running=1;

  
	if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_JOYSTICK) < 0 ) 
	{
	fprintf(stderr, "Couldn't initialize SDL: %s\n", SDL_GetError());	
	return 1;
	}
   
	screen = SDL_SetVideoMode(640,480,32,SDL_FULLSCREEN|SDL_HWSURFACE);

	SDL_Rect rect;
	rect.x=x;
	rect.y=y;
	rect.w=5;
	rect.h=10;

	Uint32 color=SDL_MapRGB(screen->format,0xff,0xff,0xff);
	Uint32 color2=SDL_MapRGB(screen->format,0x00,0x00,0x00);

	SDL_JoystickEventState(SDL_ENABLE);
	joystick = SDL_JoystickOpen(0);

  	while (running)
	{


		while(SDL_PollEvent(&event))
		{  
			switch(event.type)
			{  
				case SDL_KEYDOWN:
				/* handle keyboard stuff here */				
				break;

				case SDL_QUIT:
				/* Set whatever flags are necessary to */
				/* end the main game loop here */
				running=0;
				break;

				case SDL_JOYBUTTONDOWN:
				switch (event.jbutton.button)
				{
					case 0:
						printf("A\n");
						break;
					case 1:
						printf("B\n");
						break;
					case 2:
						printf("X\n");
						break;
					case 3:
						printf("Y\n");
						break;
					case 4:
						printf("LSh\n");
						break;
					case 5:
						printf("Rsh\n");
						break;
					case 6:
						printf("LThmb\n");
						break;
					case 7:
						printf("RThmb\n");
						break;
					case 8:
						printf("Start\n");
						running=0;
						break;
					case 9:
						printf("Back\n");
						break;
					case 10:
						printf("LTrig\n");
						break;
					case 11:
						printf("RTrig\n");
						break;					
				}
				case SDL_JOYAXISMOTION:  /* Handle Joystick Motion */
   					if( event.jaxis.which == 0 ) //If left joystick
					{
						if(event.jaxis.axis == 0) //if x axis changed
						{
							if((event.jaxis.value > -16384 ) && ( event.jaxis.value < 16384 ))
							{
								xvel=0;
							}

							if(event.jaxis.value>16384)
							{							
								xvel=1;
							}							
							if(event.jaxis.value<-16384)
							{							
								xvel=-1;					
							}
						}

						
						if(event.jaxis.axis == 1) //if y axis changed
						{
							if((event.jaxis.value > -16384 ) && ( event.jaxis.value < 16384 ))
							{
								yvel=0;
							}
							if(event.jaxis.value>16384)
							{							
								yvel=1;

							}
							if(event.jaxis.value<-16384)
							{								
								yvel=-1;

							}

						}


					}	
    				
       			 }
   		 }

		if(!(xvel==0) || !(yvel==0))
		{
		rect.x=x;
		rect.y=y;
		SDL_FillRect(screen,&rect,color2);
		SDL_Flip(screen);
		

		x+=xvel;
		
		if (x<0)
		x+=1;
		if (x>640-rect.w)
		x-=1;

		y+=yvel;

		if (y<0)
		y+=1;
		if (y>480-rect.h)
		y-=1;

		rect.x=x;
		rect.y=y;
		SDL_FillRect(screen,&rect,color);
		SDL_Flip(screen);
		}


	}


	SDL_Quit();
  
	return 0;
}






