#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <SDL/SDL.h>
#include <input/input.h>
#include "video.h"
#include <xenos/xe.h>
#include "fctSdl.h"
#include "font.h"
//#include "fatFct.h"
#include <newlib/dirent.h>

//les textures
#include "bitmap/bitmap.h"

int iSelectedItem=0;//Item Selectionner


/***
ETAT DE L'APPLICATION

***/
short emuLoaded=0;//pas d'emu lancer encore


#define nItemOnScreen 8	//Nombre d'item à l'ecran

//#define printf // elimine l'affiche de printf

#define DECALAGEROWS	155//Decalage (par rapport au haut) | xoffset

typedef struct 
{
	int type;
	char name[256];
	unsigned long filesize;
}nodeInfo_s;

typedef struct
{
	int count;
	char currentDirname[256];//Nom du repertoire courrant
	//nodeInfo_s node[2048];//nombre de fichier max par dossier
	nodeInfo_s node[2048];
}dirInfo_s;

dirInfo_s dirInfo;//Contient tous les repertoires

/** Gestion des touches de direction dans le menu **/
unsigned int handleInputValue( int nval)
{

	if(nval<0)	
		nval=0;
	if(nval>=dirInfo.count)
		nval=dirInfo.count-1;
	
	return nval;
}

/**

Ecrit le menu dans SDLScreen

**/
void DrawMenu()
{
	DEBUG("\t\t\t DrawMenu();\n");
	//SDL_FillRect(SDLScreen, 0, 0x336699FF);//Efface l'ecran en bleu
	//bouge la souris
	//Ecrit le logo
	SDL_Rect dest;
	dest.x = 0;
	dest.y = 0;
	dest.w = 1280;
	dest.h = 720;

	//SDL_Surface *bgSurf=getBitmapFromMemory(dest.w,dest.h,background);
	SDL_BlitSurface( bgSurf, NULL, SDLScreen, &dest );
	
		
	//on dessine la souris au bonne endroit
	//SDL_Rect dest;
	dest.x = 170;
	dest.y = ((iSelectedItem%nItemOnScreen)*64)+DECALAGEROWS;//Retour a la ligne
	//dest.y = 200;//Retour a la ligne
	dest.w = 64;
	dest.h = 64;


	//SDL_Surface *cursor=getBitmapFromMemory(64,64,xenonCursorData);
	//SDL_Surface *cursor=SDLprintf("O");

	SDL_BlitSurface( cursor, NULL, SDLScreen, &dest );

	listFile(dirInfo);//Liste les fichiers

}

//Liste un dossier
void listFile(dirInfo_s *directory)
{
	DEBUG("\t\t\t listFile();\n");
	//SDL_FillRect(screen, 0, 0xFF0000FF);
	SDL_Surface *string;
	int i;

	int iStart;//=0;
	int iEnd;//=nItemOnScreen;
	int NBPage=ceil(dirInfo.count/nItemOnScreen);//Nombre de pages
	int selPage=iSelectedItem/nItemOnScreen;//Page selectionner
	
	if(selPage>NBPage)
	{
		selPage=NBPage;
	}
	
	iStart=	selPage*nItemOnScreen;
	iEnd=iStart+(nItemOnScreen-1);
	if(iEnd>=dirInfo.count)
	{
		if(dirInfo.count>0)
			iEnd=dirInfo.count-1;
		else
			iEnd=0;
	}

	SDL_Rect iconDest;
	iconDest.x = 0;
	iconDest.y = 0;	
	iconDest.w = 0;
	iconDest.h = 0;

	int z=0;
	//printf("Affiche la page:%d/%d\niSelectedItem=%d\t selPage=%d\t iStart=%d\tiEnd=%d\tCount=%d\n",selPage , NBPage, iSelectedItem ,selPage, iStart, iEnd,FatLS.count );
	for(i=iStart;	i<=iEnd;	i++)
	{
	
		
		DEBUG("\t\t\t\t%s\n",directory->node[i].name);
		const char dname[256];

		sprintf(dname,"%s",directory->node[i].name);

		DEBUG("\t\t\t listFile();->//Affiche le nom de fichier\n");
		//Affiche le nom de fichier
		SDLprintf(SDLScreen,340,(64*z)+DECALAGEROWS,dname);

		DEBUG("\t\t\t listFile();->SDL_BlitSurface fileIcon\n");

		iconDest.x=260;
		iconDest.y=(64*z)+DECALAGEROWS;
		if(directory->node[i].type==0)
		{
			//fileType=getBitmapFromMemory(64,64,xenonFileData);
			SDL_BlitSurface( fileIcon, NULL, SDLScreen, &iconDest );
		}
		else
		{
			//fileType=getBitmapFromMemory(64,64,xenonFolderData);
			SDL_BlitSurface( folderIcon, NULL, SDLScreen, &iconDest );
		}
		

		z++;
		
	}	
	//Libere les ressources
	SDL_FreeSurface(string);
	//updateGFXPlane();
}

/**
Enleve les . et .. d'un path
**/
char *cleanDirname(char *path)
{

	DEBUG("\t\t\t cleanDirname();\n");
	int i;
	
	int pathLen=strlen(path);
	
	char *newPath=malloc(pathLen);

	int j=0;//compteur de la nouvelle variable
	//Sauvegarde les 2 derniers slashs
	int lastSlashPos=0;
	int curSlashPos=0;
	for(i=0;i<pathLen;i++)
	{	
		
		if(path[i]=='/')
		{
			curSlashPos=lastSlashPos;
			lastSlashPos=i;
		}
		
		if(path[i-1]=='/')
		{
			if((path[i]=='.')&&(path[i+1]=='.'))//retour en arriere
			{
				j=(curSlashPos);
				i+=2;
			}
			if((path[i]=='.'))
			{
				i++;
				j=lastSlashPos;
			}
		}
		newPath[j]=path[i];	
		j++;
	}
	newPath[j]='\0';//Fin
	return newPath;
}


/**
Lance l'emulateur ....
**/
void doEmulation()
{
	char newDir[256];
	sprintf(newDir,"%s/%s",dirInfo.currentDirname,dirInfo.node[iSelectedItem].name);
	smsmain(cleanDirname(newDir));
}

/**

Une action est à realisé

**/
void HandleAction()
{
	
	DEBUG("\t\t\t HandleAction();\n");
	printf("\t\t\t\t%d-%s\n",dirInfo.node[iSelectedItem].type,dirInfo.node[iSelectedItem].name);
	if(dirInfo.node[iSelectedItem].type==1)//Dir
	{
		
		char newDir[256];
		sprintf(newDir,"%s/%s",dirInfo.currentDirname,dirInfo.node[iSelectedItem].name);
		updateCurDir(newDir);
	}
	if(dirInfo.node[iSelectedItem].type==0)//A tester si c une rom !!
	{
		
//		updateCurDir(newDir);
		emuLoaded=1;
	}

}


//Mets à jour la valeur de FatLS (Dossier en cours)
void updateCurDir(const char *dirName)
{
	DEBUG("\t\t\t updateCurDir();\n");
	char *cleanedDirName=cleanDirname(dirName);

	usb_do_poll();
	dirInfo_s currentDirInfo;

	strcpy(currentDirInfo.currentDirname,cleanedDirName);

	//init cdi
	currentDirInfo.count=0;
	
	struct dirent *lecture;
	DIR *rep;
	//rep= opendir("uda:" );
	rep= opendir(cleanedDirName );
	
	while ((lecture = readdir(rep))) {
		//Accepte que certaine extention
		if(lecture->d_type==0x01)
		{
			//printf("\t\t\t0x%02x--%s\n",lecture->d_type, lecture->d_name);
			strcpy(currentDirInfo.node[currentDirInfo.count].name,lecture->d_name);
			currentDirInfo.node[currentDirInfo.count].type=lecture->d_type;
			currentDirInfo.count++;
		}
		else
		{	
			if((strstr(lecture->d_name,".ZIP"))||(strstr(lecture->d_name,".SMS"))||(strstr(lecture->d_name,".GG")))
			{
				strcpy(currentDirInfo.node[currentDirInfo.count].name,lecture->d_name);
				currentDirInfo.node[currentDirInfo.count].type=lecture->d_type;
				currentDirInfo.count++;
			}
		}
	}
	closedir(rep); 
	//copie dans le global
	dirInfo=currentDirInfo;
}

//Bouton Appuyer
void pushBtn(struct controller_data_s controller_data)
{
	DEBUG("\t\t\t pushBtn();\n");
	if(controller_data.up)
	{
		iSelectedItem--;
		
	}
	if(controller_data.down)
	{
		iSelectedItem++;
	}
	if(controller_data.a)	
	{
		HandleAction();
	}
	
	iSelectedItem=handleInputValue(iSelectedItem);//Mets à jour la valeur
	DrawMenu();//Dessine le menu (list des fichiers)
	updateGFXPlane();
	drawBg(1280,720);
	updateScreen(1280,720);
	//mdelay(200);//attends 200m secondes
}



void mainInit()
{
	//init
	xenos_init();
	console_init();

	kmem_init();
	usb_init();

	initSDLScreen();
	initScreen(1280,720);
	drawBg(1280,720);

}


void menu()
{

	//usb_do_poll(); // pas besoin ?!

	//Se place à la racine de la premiere clef usb
	updateCurDir("uda:");
	emuLoaded=0;//Emu pas lancer on est dans le menu

	//Boucle du menu
	while(emuLoaded==0)
	{
		struct controller_data_s c;
		if (get_controller_data(&c, 0))
		{
			pushBtn(c);
		}
		usb_do_poll();
	}
	//Lance l'emulation et quitte cette boucle
	doEmulation();
}

/**
Le but principal est de jamais quitter le main
**/
int main(void)
{
	while(1)
	{
		mainInit();
		menu();
	}
	return 0;
}
