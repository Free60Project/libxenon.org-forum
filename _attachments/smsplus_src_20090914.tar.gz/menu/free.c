/**
Libères les ressources creer par le menu
@ todo
**/

