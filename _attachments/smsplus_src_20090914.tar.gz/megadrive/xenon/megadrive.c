#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <xenos/xe.h>
#include <input/input.h>
#include <time/time.h>
#include <ppc/timebase.h>
#include "shared.h"


#include "smsmain.h"
#include "xenon_video.h"

#include <SDL/SDL.h>
#include "shared.h"

//#define DEBUG printf("\tDEBUG %s:%s(); at line %d:",__FILE__,__func__,__LINE__ );

/** Initialisation de la console **/
void xb360Init()
{
	xenos_init();
	console_init();
	xenon_sound_init();
	kmem_init();
	
	usb_init();
	usb_do_poll();
}

/***
Frameskipping
***/

unsigned long long prev, now;

unsigned long long gettime(void)
{
        return mftb();
}

int diff_usec(unsigned long long prev, unsigned long long now)
{
        return (now - prev) /(PPC_TIMEBASE_FREQ/1000000);
}

//Attends jusqu'a la prochaine frame
int frameSkip()
{
	int fpshz=(1) ? 16667 : 20000;//16667
	now=gettime();

	unsigned long diff=diff_usec(prev,now);


        while (diff_usec(prev, now) < fpshz)
        {
                now = gettime();
                udelay(50);
        }
	
	prev = now;
}


/***
INPUT HANDLING
***/

int update_input(void)
{
	/* Reset all inputs */
	memset(&input, 0, sizeof(input));

	/** 
	
	structure contenant les données de la manette

	**/
	struct controller_data_s c;
	get_controller_data(&c, 0);
	//processKey(c,0);

	int iJoystick=0;

	//a ajouter une config
	if(c.a)
	{
		input.pad[iJoystick] |= INPUT_A;
	}
	if(c.b)
	{
		input.pad[iJoystick] |= INPUT_B;
	}
	if(c.start)
	{
		input.pad[iJoystick] |= INPUT_START;
	}
	if(c.up)
	{
		input.pad[iJoystick] |= INPUT_UP;
	}
	if(c.down)
	{
		input.pad[iJoystick] |= INPUT_DOWN;
	}
	if(c.left)
	{	
		input.pad[iJoystick] |= INPUT_LEFT;
	}
	if(c.right)
	{
		input.pad[iJoystick] |= INPUT_RIGHT;
	}

	//mets à jour les données du stick
	usb_do_poll();
}

/***
SOUND
***/

void updateSound()
{
	xenon_sound_submit(snd.buffer[0], snd.buffer_size * 2);
	xenon_sound_submit(snd.buffer[1], snd.buffer_size * 2);
}


/**
MAIN

***/

int main ()
{

	//printf("\t\t\tinit ....\n");
	//Initialisation de l'affichage et Initialisation de la console
	xb360Init();
	initVideo();

	int running = 1;
	
	error_init();
	
	printf("\t\t\tinit ....Ok\n");
	/* Load game */
	if(!load_rom("uda:/SONIC.BIN"))
	{
		char caption[256];
		sprintf(caption, "Error loading file `%s'.", "sonic.bin");
		//MessageBox(NULL, caption, "Error", 0);
		printf("\t\t\t%s",caption);
		exit(1);
	}
	printf("\t\t\tmemset\n");
	memset(&bitmap, 0, sizeof(t_bitmap));
	bitmap.width  = 256;
	bitmap.height = 224;
	bitmap.depth  = 16;
	bitmap.granularity = 2;

	printf("\t\t\tbitmap.pitch\n");

	bitmap.pitch = gfxplane->pitch;
	bitmap.data   = (uint16*)(((unsigned char*)gfxplane->base) + gfxplane->pitch * 2 + 2 * 2);
	bitmap.viewport.w = 256;
	bitmap.viewport.h = 224;
	bitmap.viewport.x = 0x00;
	bitmap.viewport.y = 0x20;
	bitmap.remap = 1;
	
	printf("\t\t\tsystem_init\n");

	system_init();
	system_reset();

	printf("\t\t\trunning");

	audio_init(44100);
	while(running)
	{
		update_input();
		frameSkip();
		system_frame(0);//avance
		updateVideo();
		updateSound();
	}

	system_shutdown();
	error_shutdown();

	return 0;
}


/* Check if a key is pressed */
int check_key(int code)
{
#if 0
    static char lastbuf[0x100] = {0};

    if((!keystate[code]) && (lastbuf[code] == 1))
        lastbuf[code] = 0;

    if((keystate[code]) && (lastbuf[code] == 0))
    {
        lastbuf[code] = 1;
        return (1);
    }                                                                    
#endif
    return (0);
}




