
#ifndef _LOADROM_H_
#define _LOADROM_H_

/* Function prototypes */
void deinterleave_block(uint8 *src);
int load_rom(char *filename);

#endif /* _LOADROM_H_ */

