
#ifndef _OSD_H_
#define _OSD_H_

#include <stdio.h>
#include <allegro.h>
#include <string.h>
#include <audio.h>
#include <time.h>
#include <conio.h>

#include "shared.h"
#include "dos.h"
#include "config.h"
#include "sealintf.h"
#include "error.h"
#include "unzip.h"
#include "fileio.h"

volatile int frame_count;

#endif /* _OSD_H_ */
