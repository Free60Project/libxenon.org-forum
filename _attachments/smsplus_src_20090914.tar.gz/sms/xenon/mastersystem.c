#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <xenos/xe.h>
#include <input/input.h>
#include <time/time.h>
#include <ppc/timebase.h>
#include "shared.h"


#include "smsmain.h"
#include "xenon_video.h"


//Valeur utilisé lors de la boucle d'emulation
short exitRequested=0;//Retour au menu
short emulationPaused=0;//Jeux en pause


uint64_t ld(volatile void *addr)
{
	uint64_t l;
	asm volatile ("ld %0, 0(%1)" : "=r" (l) : "r" (addr));
	return l;
}

void system_manage_sram(uint8 *sram, int slot, int mode)
{
//    @todo
}

static inline uint32_t bswap_32(uint32_t t)
{
        return ((t & 0xFF) << 24) | ((t & 0xFF00) << 8) | ((t & 0xFF0000) >> 8) | ((t & 0xFF000000) >> 24);
}


/***
Merci tmbinc :)
**/
void updateSound(int16 **output,int length)
{
	int sample_rate = 48000 * 2;

	int samples_per_frame = (sms.display == DISPLAY_NTSC) ? sample_rate / 60 : sample_rate / 50;

	int req_samples = samples_per_frame;

	int samples[48000/2];//Grandes valeurs ... ( à revoirs ...)
	int i;
	for(i = 0; i < length; i++)
	{
		int left = output[0][i];
		int right = output[1][i];
		left &= 0xFFFF;//strips of the sign-extended bits
		right &= 0xFFFF;//strips of the sign-extended bits
		samples[i] = bswap32((left << 16) | right);
	}
	xenon_sound_submit(samples,length*2);
	
}

//Hard Coded Input
void updateInput()
{
	/* Reset all inputs */
	memset(&input, 0, sizeof(input));

	/** 
	
	structure contenant les données de la manette

	**/
	struct controller_data_s c;
	get_controller_data(&c, 0);

	int iJoystick=0;

	//a ajouter une config
	if(c.a)
	{
		input.pad[iJoystick] |= INPUT_BUTTON1;
	}
	if(c.b)
	{
		input.pad[iJoystick] |= INPUT_BUTTON2;
	}
	if(c.start)
	{
		input.pad[iJoystick] |= input.system |= INPUT_START;
	}
	if(c.up)
	{
		input.pad[iJoystick] |= INPUT_UP;
	}
	if(c.down)
	{
		input.pad[iJoystick] |= INPUT_DOWN;
	}
	if(c.left)
	{	
		input.pad[iJoystick] |= INPUT_LEFT;
	}
	if(c.right)
	{
		input.pad[iJoystick] |= INPUT_RIGHT;
	}
	if(c.select)
	{
		exitRequested=1;
	}
#if 0	
	if(c.lb)
	{
		if(emulationPaused==0)
			emulationPaused=1;
		else
			emulationPaused=0;
	}
#endif
	//mets à jour les données du stick
	usb_do_poll();
}


/** Initialisation de la console **/
void xb360Init()
{
	xenos_init();
	console_init();
	xenon_sound_init();
	//kmem_init();
	//usb_init();
	/*
	struct bdev *f;
	do {
		usb_do_poll();
		f = bdev_open("uda");
		if (f)
			break;
	} while (1);

	if(f)
	{	
		if (	fat_init(f)	)
		{
			printf("Erreur");
		}
	}*/
	//Init FileSystem
	
}


/**

Limiteur de vitesse

**/


unsigned long long prev, now;

unsigned long long gettime(void)
{
        return mftb();
}

int diff_usec(unsigned long long prev, unsigned long long now)
{
        return (now - prev) /(PPC_TIMEBASE_FREQ/1000000);
}


int frameSkip()
{
	int fpshz=(snd.fps==FPS_NTSC ) ? 16667 : 20000;//16667
	now=gettime();

	unsigned long diff=diff_usec(prev,now);


        while (diff_usec(prev, now) < fpshz)
        {
                now = gettime();
                udelay(50);
        }
	
	prev = now;
}


void getrusage(){};

void setupSmsplus()
{
	//Valeur par defaut
	exitRequested=0;
	emulationPaused=0;
	
	//Setup Sms plus
	memset(&bitmap, 0, sizeof(bitmap_t));

	//alloue la bonne taille selon le system
	if(sms.console == CONSOLE_GG)
	{
		bitmap.width  = 160;
		bitmap.height = 146;
		bitmap.viewport.w = 160;
		bitmap.viewport.h = 146;
	}
	else if(sms.console== CONSOLE_SMS )
	{
		bitmap.width  = 256;
		bitmap.height = 192;
		bitmap.viewport.w = 256;
		bitmap.viewport.h = 192;
	}

	bitmap.depth  = 16;
	bitmap.granularity = 2; 
	//Attention
	bitmap.pitch  = gfxplane->pitch;
	//gfxplane>bitmap.data
	bitmap.data   = (uint16*)(((unsigned char*)gfxplane->base) + gfxplane->pitch * 2 + 2 * 2);
	bitmap.viewport.x = 0;
	bitmap.viewport.y = 0;

	
	snd.fm_which = SND_EMU2413;
	snd.fps = (sms.display == DISPLAY_NTSC) ? FPS_NTSC : FPS_PAL;
	snd.fm_clock = (sms.display == DISPLAY_NTSC) ? CLOCK_NTSC : CLOCK_PAL;
	snd.psg_clock = (sms.display == DISPLAY_NTSC) ? CLOCK_NTSC : CLOCK_PAL;
	snd.sample_rate = 48000;//test pour le son
	snd.mixer_callback = NULL;

	sms.territory = 0;
	sms.use_fm = 0;

	system_init();

	system_poweron();
}

#ifdef DNOMENU
int main(void)
#else
int smsmain(char romName)
#endif
{	
/*
	SDL_FillRect(SDLScreen, 0, 0x00000000);

	SDLprintf(500,400,"Loading ...");
	//UPDATE
	updateGFXPlane();
	drawBg(1280,720);
	updateScreen(1280,720);
*/
	//Copie la rom dans cart.rom
	if(load_rom(romName) == 0)
	{
		printf("\n\t\tError loading `%s'.\n",romName);
		//erreur de copie
		return 0;
	}
	else
	{
		printf("\n\t\t\trom charger\n");
	}

	//Initialisation de l'affichage et Initialisation de la console
	xb360Init();
	initVideo();

	setupSmsplus();

	while (exitRequested==0)
	{
		if(emulationPaused==0)
		{
			system_frame(0);
			updateSound( snd.output, snd.buffer_size  );
			updateVideo();
			frameSkip();
		}
		//Dans tous les cas on test les inputs
		updateInput();
	}
	//Remise a zero des valeurs
	system_poweroff();

	return 0;
}
