in_vgm source files
===================

Made with VC6. Please let me know if I've missed out any files.
Uses ZLib (not included), EMU2413 (included), a modified version
of some MAME FM cores (included) and Gens' YM2612 core (included).

Many thanks to BlackAura for getting the MAME stuff working.

Please note that I am not vastly experienced in C, so there may well be
some stupid stuff in this source.

You are allowed to do what you like with it just so long as:

1. You let me know if you distribute it (any included files or
   anything derived from them), and
2. You don't pass it off as your own.

Maxim
maxim@mwos.cjb.net
