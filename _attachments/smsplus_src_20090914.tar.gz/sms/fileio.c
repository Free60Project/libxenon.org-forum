/*
    fileio.c --
    File management.
*/
#include <diskio/diskio.h>
#include <fat/fat.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "shared.h"


uint8 *loadFromZipByName(char *archive, char *filename, int *filesize)
{
	printf("\t\t\tloadFromZipByName(%s)\n",archive);

    char name[PATH_MAX];
    unsigned char *buffer;

    int zerror = UNZ_OK;
    unzFile zhandle;
    unz_file_info zinfo;

    zhandle = unzOpen(archive);
    if(!zhandle) 
	{
printf("\t\t\tunzOpen(archive)=>%d\n",zhandle);
return (NULL);
	}

    /* Seek to first file in archive */
printf("\t\t\t Seek to first file in archive (%s)\n",archive);
    zerror = unzGoToFirstFile(zhandle);
    if(zerror != UNZ_OK)
    {
        unzClose(zhandle);
        return (NULL);
    }

    /* Get information about the file */

	printf("\t\t\t unzClose(zhandle) (%s)\n",archive);
    unzGetCurrentFileInfo(zhandle, &zinfo, &name[0], 0xff, NULL, 0, NULL, 0);
    *filesize = zinfo.uncompressed_size;

    /* Error: file size is zero */
    if(*filesize <= 0)
    {
        unzClose(zhandle);
        return (NULL);
    }
printf("\t\t\t   Open current file; (%s)\n",archive);
    /* Open current file */
    zerror = unzOpenCurrentFile(zhandle);
    if(zerror != UNZ_OK)
    {
	
        unzClose(zhandle);
        return (NULL);
    }

    /* Allocate buffer and read in file */
    buffer = malloc(*filesize);
    if(!buffer) return (NULL);
    zerror = unzReadCurrentFile(zhandle, buffer, *filesize);

	printf("\t\t\t   Internal error: free buffer and close file (%s)\n",archive);
    /* Internal error: free buffer and close file */
    if(zerror < 0 || zerror != *filesize)
    {
        free(buffer);
        buffer = NULL;
        unzCloseCurrentFile(zhandle);
        unzClose(zhandle);
        return (NULL);
    }

    /* Close current file and archive file */
    unzCloseCurrentFile(zhandle);
    unzClose(zhandle);

    memcpy(filename, name, PATH_MAX);
    return (buffer);
}

/*
    Verifies if a file is a ZIP archive or not.
    Returns: 1= ZIP archive, 0= not a ZIP archive
*/
int check_zip(char *filename)
{
	printf("\t\t\tcheck_zip=>%s\n",filename);
	uint8 buf[2];
	int fd;
	fd = open(filename, O_RDONLY);
	if(!fd) 
	{
		printf("\t\t\tFichier existe pas=>%s\n",filename);
		return (0);
	}
	read(fd, buf,2 );
	//fclose(fd);

	printf("\t\t\tCompare=>%s\n",filename);
	if(memcmp(buf, "PK", 2) == 0) return (1);

	printf("\t\t\tcpas un zip :s=>%s\n",filename);
	return (0);
}


/*
    Returns the size of a GZ compressed file.
*/
int gzsize(gzFile *gd)
{
    #define CHUNKSIZE   (0x10000)
    int size = 0, length = 0;
    unsigned char buffer[CHUNKSIZE];
    gzrewind(gd);
    do {
        size = gzread(gd, buffer, CHUNKSIZE);
        if(size <= 0) break;
        length += size;
    } while (!gzeof(gd));
    gzrewind(gd);
    return (length);
    #undef CHUNKSIZE
}




