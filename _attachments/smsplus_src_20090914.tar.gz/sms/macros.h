
#ifndef _MACROS_H_
#define _MACROS_H_

#define CLRMEM(p)   memset(p, 0, sizeof(p))

#endif /* _MACROS_H_ */
