#ifndef _VIDEO_H_
#define _VIDEO_H_

/* Function prototypes */
void dos_video_init(void);
void dos_video_shutdown(void);
void osd_update_video(void);
void update_palette(void);

#endif /* _VIDEO_H_ */

