--== Team Xecuter's Xenon Reset Glitch Hack ==--

 
Wiring
---------
 
Generate your ecc image using the latest version of J-Runner and flash to your NAND 
(+w16 just like a regular RGH).
 
Program your TX CoolRunner (or whatever flavor RGH mod you are using) with the 
tx-xenon.xsvf or tx-xenon.jed file.
 
The Xenon has a capacitor on CPU_RST that was removed in later models.  C7R112 (located 
near the xclamp under the CPU) must be de-soldered, and the CPU_RST wire from the 
TX CoolRunner(D) must be soldered to the left pad (non grounded pad).  
 
A 47nf ( 0.047uf) capacitor needs to be added between PLL_BYPASS(+) and GND(-). (If you 
have a genuine TX CoolRunner REV B you can use the on-board by bridging the CAP jumper)
 
A 220-270pf capacitor should be added between CPU_RST(+) and GND(-) on the cpld. (If you 
have a genuine TX CoolRunner REV B this is already included in the design so not required)
 
An easy to follow picture guide can be found here: 
http://www.team-xecuter.com/coolrunner/install/phat_xenon.jpg
 
 
 
Troubleshooting
----------------------

Using a TX CoolRunner Rev B, and after applying various troubleshooting measures we have
had glitches ranging from instant to 20 minutes.
 
The debug LED should flash on for less than a second and repeat every 5 seconds.  If your 
LED stays on or does not come on at all, it is usually because of something being wrong 
with PLL_BYPASS.  Try different values of capacitors and wires. If you have enabled the 
CAP on REV B of the TX CoolRunner, simply un-bridge it and try a 47nF cap instead as per 
the instructions above.
 
If it still has not glitched after several hours, try different values of capacitors on 
CPU_RST of your RGH mod.  A longer wire / low-loss 50 ohm double shielded cable may also 
help with this.
 
To help increase boot times and stability (on all RGH installs not just Xenon) we recommend 
that you try Low-Loss Double Shielded 50 ohm cable. It's very cheap to use and quite effective 
- so a quick shout out to www.xconsoles.com who supplied a batch of high quality cable for 
our development team to use. It's less than 75 cents a foot - not bad.
 
NOTE: Remember when programming the TX CoolRunner that the Xbox power is NOT connected and 
that the switch is set to PRG before you connect the JTAG cable. If you connect the JTAG 
cable and it is set to NOR with the Xbox power connected, it can damage your NAND-X and/or 
CoolRunner. When you have finished programming, switch it back to NOR and then power on the Xbox.
 
 
 
The Xenon Hack
-----------------------

Please note that this hack is not available on consoles updated to dashboards 14717 or 14719.
 
If you are seeing the debug led it means that the cpu is probably not crashing and the issue 
addressed by gligli/tiros has been fixed (This can of course be a false positive as sometimes 
the CPU could be crashing but the SMC restarts fine - we can never be 100% sure)

So far, this is really only useful for a one time cpu_key dump. There will undoubtedly be ways 
of optimizing this hack in the future and who knows, it may become a reliable glitch one day.  
 
We would appreciate that you give as much feedback to our support forums as possible to help 
others achieve better results and to improve this method. For now we can leave this and go 
back to RGH2.0 for Zephyr, Falcon, Jasper and also of course, the Corona.
 
TX CoolRunner Support Forums: http://www.team-xecuter.com/forums/forumdisplay.php?f=174
 
Enjoy!
 
Xbox 360 Xenon RGH Hack brought to you by the Xecuter RGH Development Team
 
www.team-xecuter.com


Thanks
------------

Thanks are extended to Tiros & Gligli, without your work none of this would have been possible.

A special thanks goes out to cOz - your work on Dashlaunch proved to be an invaluable contribution
and we look froward to your next exciting project.

Greets: Team Jungle, Team FSD, Freeboot, Libxenon & RGLoader.

