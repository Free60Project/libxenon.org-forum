Xmenu 0.1
=========

Xmenu is an elf loader with a basic gui.


Changelog
=========

Version 0.1 : Alpha testing version.


Thanks
======
Sasoseso from xboxhacker.net for sending me a free xbox 360, if all the people could be like you :)
Tmbinc of course for all his work.
Ced2911 for sega master system emulators sources, helped me a lot.
Ge0rG and ssmurf, because they are nice guys :)


