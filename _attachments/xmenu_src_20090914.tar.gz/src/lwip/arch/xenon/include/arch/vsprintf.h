#ifndef __vsprintf_h
#define __vsprintf_h

int sprintf(char * buf, const char *fmt, ...);
int printf( const char *fmt, ...);

#endif
