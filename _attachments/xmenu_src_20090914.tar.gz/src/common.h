#ifndef _COMMON_H
#define _COMMON_H

int load;
int stop;
char progress[128];

#endif
