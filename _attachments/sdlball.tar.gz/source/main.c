#include <stdio.h>
#include <xenos/xenos.h>
#include <console/console.h>
#include <libfat/fat.h>
#include <usb/usbmain.h>
#include <diskio/ata.h>
#include <math.h>
#include <SDL/SDL.h>

#define	PI	3.14159265358979323846

void mainInit(){
	xenos_init(VIDEO_MODE_AUTO);
	console_init();

	kmem_init();
	usb_init();
	usb_do_poll();
	fatInitDefault();
}




int main(int argc, char* argv[])
{
	mainInit();
	SDL_Surface *screen;
	SDL_Surface *ball;
	int k;
	float a=0.25,b=0.25;
	float x=0,y=0,theta=0;

	if (SDL_Init(SDL_INIT_VIDEO) < 0 ) 
	{
		fprintf(stderr, "Couldn't initialize SDL: %s\n", SDL_GetError());	
		SDL_Quit();
	}
   
	screen = SDL_SetVideoMode(640,480,32,SDL_FULLSCREEN|SDL_HWSURFACE);
	ball=SDL_LoadBMP("uda://ball.bmp");
	if (ball == NULL) {
		printf("Unable to load bitmap: %s\n", SDL_GetError());
		SDL_Delay(60000);
		return 1;
	}

	Uint32 color=SDL_MapRGB(screen->format,0x00,0x00,0x00);

	SDL_Rect offset;
	offset.x=0;
	offset.y=0;

	SDL_Rect rect;
	rect.x=x;
	rect.y=y;
	rect.w=32;
	rect.h=32;

	for(k=0;k<110;k++)
	{
		if(k==0)
		{
			x=0;
			y=0;
		}
		else
		{
			x=a*cos(theta)*exp(b*theta);
			y=a*sin(theta)*exp(b*theta);
		}
		offset.x=(int)x+320;
		offset.y=(int)y+240;
		rect.x=(int)x+320;
		rect.y=(int)y+240;
		theta=k*(PI/12);

		SDL_BlitSurface(ball,NULL,screen,&offset);
		SDL_Flip(screen);
		SDL_Delay(25);
		SDL_FillRect(screen,&rect,color);
		SDL_Flip(screen);

	}


	SDL_Delay(60000);


  
	return 0;
}






